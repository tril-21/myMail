﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using System.Threading;

namespace Mail
{
    public partial class AdminMail : Form
    {

        private Form1 form_auto; //ссылка на главную форму проекта (авторизация)
        private string Login = ""; //используется для запроса все строчек из таблицы базы данных. отображается datagridview
        private string NameUser = ""; //используется для отображения имени пользователя
        private string KEY_row = ""; //ключ для выборки строчки из таблицы отправителя
        private string KEY_row_Admin = "";//ключ для выборки строчки из таблицы администратора
        private string LoginSendler = "";//общая переменная для определения имени пользователя

        private string query_Update = "";

        public static string connectStringForMail = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_MailUsers.accdb;"; //строка для подключения к базе данных

        private OleDbConnection myConnection;//переменная для установления соединения с базой данных
        public AdminMail(Form1 f, string login, string name)
        {
            InitializeComponent();
            form_auto = f;//получаем ссыоку на окно авторизации

            Login = login;//задаем значения логина
            NameUser = name;//задаем значение имени пользователя

            label1.Text = "Пользователь: " + NameUser;//отображение на форме

            query_Update= "SELECT * FROM " + Login;

            dataGridView1.DataSource = GetEmployeesList();//обновляем список таблицы
        }

        //событие срабатывающее при закрытии формы
        private void AdminMail_FormClosing(object sender, FormClosingEventArgs e)
        {
            form_auto.Close();//закрываем окно авторизации для отключения всей программы
        }

        //событие отвечающее за обновление таблицы на форме
        private DataTable GetEmployeesList()
        {
            myConnection = new OleDbConnection(connectStringForMail);//устанавливаем соединение
            myConnection.Open();//откраваем соединение
            DataTable dtE = new DataTable();//переменная для таблицы

            string query = query_Update; //запрос на выборку

            OleDbCommand command = new OleDbCommand(query, myConnection);//создаем команду
            OleDbDataReader reader = command.ExecuteReader();//выполняем команду

            dtE.Load(reader);//загружаем результат команды в переменную таблицы
            myConnection.Close();//закрывает соединение

            return dtE;//возвращаем таблицу
        }

        //событие отвечающщее за нажатие элемента строчки
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index_Row = e.RowIndex;//присваиваем значение выбраной строчки 
            if (index_Row < 0) //условие если выбрана строка заголовков
            {

            }
            else
            {
                KEY_row = dataGridView1.Rows[index_Row].Cells[5].Value.ToString();//присваиваем ключ в соответсвии строчки таблицы
                LoginSendler = dataGridView1.Rows[index_Row].Cells[1].Value.ToString();//присваиваем логин в соответсвии с таблицей
                KEY_row_Admin = dataGridView1.Rows[index_Row].Cells[0].Value.ToString();//присваим ключ админа в соответствии с таблицей
            }
        }

        //событие отвечающее за нажатие кнопки открыть
        private void button2_Click(object sender, EventArgs e)
        {
            if (KEY_row != ""&&check_upload_CheckNumber())//условие если не выбрана строка
            {
                upload_CheckNumber(get_Login_Sendler());
                SendViewForm Send_Form = new SendViewForm(null, this, "Admin", KEY_row);//создаем форму для внесения изменения 
                this.Hide();//скрываем данную форму
                Send_Form.Show();//открываем новую форму для изменения
            }
            else
            {
                MessageBox.Show("Укажите, нажав левой кнопкой мыши, в таблице нужное Вам отправление.");//сообщение об ошибке для пользователя
            }
        }

        private bool check_upload_CheckNumber()
        {
            bool is_free = true;
            myConnection = new OleDbConnection(connectStringForMail);//устанавливаем соединение
            myConnection.Open();//откраваем соединение

            string query = "SELECT * FROM [check_admin]";//запрос на выборку

            OleDbCommand command = new OleDbCommand(query, myConnection);//создаем команду
            OleDbDataReader reader = command.ExecuteReader();//выполняем команду

            while (reader.Read())
            {
                if (reader[1].ToString() == get_Login_Sendler())
                {
                    is_free = false;
                    break;
                }

            }
            myConnection.Close();//закрывает соединение

            return is_free;
        }
        public void upload_CheckNumber(string log_st)
        {
            myConnection = new OleDbConnection(connectStringForMail);//устанавливаем соединение
            myConnection.Open();//откраваем соединение

            string query = "UPDATE [check_user] SET [Исполнитель]='" + log_st + "' WHERE [Код]=1";

            OleDbCommand command = new OleDbCommand(query, myConnection);

            command.ExecuteNonQuery();

            myConnection.Close();//закрывает соединение*/
        }

        //событие возвращающая ключ отправления из таблицы
        public string get_KeyRow()
        {
            return KEY_row;
        }

        //событие возвращающая логин отправителя из таблицы
        public string get_Login_Sendler()
        {
            return LoginSendler;
        }

        //событие возвращающая ключ отправления админа
        public string get_KeyRowAdmin()
        {
            return KEY_row_Admin;
        }

        //событие обновления таблицы
        public void update_DataGridView()
        {
            dataGridView1.DataSource = GetEmployeesList();
        }

        //событие изменения цвета строки в соответствии с статусом отправки и отчета
        private void dataGridView1_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            DataGridView grid = sender as DataGridView; //переменная в которой поле таблицы из текущей формы

            if (grid != null)//условие что таблица существует
            {
                if (dataGridView1[6, e.RowIndex].Value.ToString() == "Не отправлено")//условие на определение цвета
                    grid.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Red;//задаем цвет для строки относительно выполненного условия
                else if ((dataGridView1[6, e.RowIndex].Value.ToString() == "Отправлено" && dataGridView1[7, e.RowIndex].Value.ToString() == "Есть не все") || dataGridView1[6, e.RowIndex].Value.ToString() == "Есть ошибки")//условие на определение цвета
                    grid.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Yellow;//задаем цвет для строки относительно выполненного условия
                else if (dataGridView1[6, e.RowIndex].Value.ToString() == "Отправлено" && dataGridView1[7, e.RowIndex].Value.ToString() == "Есть")//условие на определение цвета
                    grid.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Green;//задаем цвет для строки относительно выполненного условия
            }
        }

        //событие отвечающщее за нажатие элемента строчки
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index_Row = e.RowIndex;
            if (index_Row < 0)
            {

            }
            else
            {
                KEY_row = dataGridView1.Rows[index_Row].Cells[5].Value.ToString();
                LoginSendler = dataGridView1.Rows[index_Row].Cells[1].Value.ToString();
                KEY_row_Admin = dataGridView1.Rows[index_Row].Cells[0].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            update_DataGridView();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            update_DataGridView();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Filter_Form filter = new Filter_Form(this,null, "Admin", Login);
            this.Hide();
            filter.Show();
        }

        public void change_queryUpdate(string query)
        {
            query_Update = query;
        }
    }
}
