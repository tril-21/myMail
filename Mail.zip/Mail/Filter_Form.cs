﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using System.Diagnostics;

namespace Mail
{
    public partial class Filter_Form : Form
    {
        private AdminMail admin_mail;
        private UserMail user_mail;

        private string Main_Login = "";

        private string Regime_Main="";

        public Filter_Form(AdminMail f1, UserMail f2, string regime, string Login)
        { 
            InitializeComponent();
            admin_mail = f1;
            user_mail = f2;
            Regime_Main = regime;

            Main_Login = Login;

            switch (regime)
            {
                case "Admin":
                    break;
                case "User":
                    break;
            }
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query_Update = "SELECT [Код], [Дата], [Время], [№ дела], [Тема], [Статус отправки], [Статус отчета] FROM " + Main_Login;

            if (checkBox1.Checked|| checkBox2.Checked || checkBox3.Checked || checkBox4.Checked || checkBox5.Checked)
                query_Update += " WHERE";

            if (checkBox1.Checked&&textBox1.Text!=null)
            {
                query_Update = query_Update + "[№ дела]='" + textBox1.Text.ToString() + "'";
                if (checkBox2.Checked || checkBox3.Checked || checkBox4.Checked || checkBox5.Checked)
                    query_Update += ",";
            }
            if (checkBox2.Checked&&comboBox1.SelectedItem!=null)
            {
                query_Update = query_Update + "[Тема]='" + comboBox1.SelectedItem + "'";
                if (checkBox3.Checked || checkBox4.Checked || checkBox5.Checked)
                    query_Update += ",";
            }
            if (checkBox3.Checked && comboBox2.SelectedItem != null)
            {
                query_Update = query_Update + "[Месяц]='" + comboBox1.SelectedItem + "'";
                if (checkBox4.Checked || checkBox5.Checked)
                    query_Update += ",";
            }
            if (checkBox4.Checked && comboBox3.SelectedItem != null)
            {
                query_Update = query_Update + "[Год]='" + comboBox1.SelectedItem + "'";
                if (checkBox5.Checked)
                    query_Update += ",";
            }
            if (checkBox5.Checked && comboBox4.SelectedItem != null)
            {
                query_Update = query_Update + "[Статус отправки]='" + comboBox4.SelectedItem + "'";
            }

            switch (Regime_Main)
            {
                case "Admin":
                    admin_mail.change_queryUpdate(query_Update);
                    admin_mail.update_DataGridView();
                    this.Close();
                    break;
                case "User":
                    user_mail.change_queryUpdate(query_Update);
                    user_mail.UpdateDataGridView();
                    this.Close();
                    break;
            }
        }

        private void Filter_Form_FormClosing(object sender, FormClosingEventArgs e)
        {
            switch (Regime_Main)
            {
                case "Admin":
                    admin_mail.Show();
                    break;
                case "User":
                    user_mail.Show();
                    break;
            }
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 0)
                e.Handled=true;
        }

        private void comboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 0)
                e.Handled = true;
        }

        private void comboBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 0)
                e.Handled = true;
        }

        private void comboBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 0)
                e.Handled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query_Update = "SELECT [Код], [Дата], [Время], [№ дела], [Тема], [Статус отправки], [Статус отчета] FROM " + Main_Login;
            switch (Regime_Main)
            {
                case "Admin":

                    break;
                case "User":
                    user_mail.change_queryUpdate(query_Update);
                    user_mail.UpdateDataGridView();
                    this.Close();
                    break;
            }
        }
    }
}
