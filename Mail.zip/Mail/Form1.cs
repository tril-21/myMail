﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Mail
{
    public partial class Form1 : Form
    {
        // строка подключения к MS Access
        // вариант 1
        // public static string connectString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ListM.mdb;";
        // вариант 2
        public static string connectString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_Users.accdb;";

        // поле - ссылка на экземпляр класса OleDbConnection для соединения с БД
        private OleDbConnection myConnection;

        public Form1()
        {
            InitializeComponent();
            autoInput();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            check_PowerOff();

            if (checkBox1.Checked&&!check_namePC_AutoInput())
            {
                insert_namePC_AutoInput();
            }else if (checkBox1.Checked && check_namePC_AutoInput())
            {
                update_namePC_AutoInput();
            }else if (checkBox1.Checked == false&&check_namePC_AutoInput())
            {
                delete_namePC_AutoInput();
            }
            
            // создаем экземпляр класса OleDbConnection
            myConnection = new OleDbConnection(connectString);

            // открываем соединение с БД
            myConnection.Open();

            string query = "SELECT * FROM [users] WHERE [Логин]='"+textBox1.Text.ToString()+"'";

            OleDbCommand command = new OleDbCommand(query, myConnection);

            OleDbDataReader reader = command.ExecuteReader();

            if (reader.HasRows == false)
            {
                MessageBox.Show("Пользователя не существует. Пожалуйста зарегистрируйтесь.");
                myConnection.Close();
            } else
            {
                reader.Read();
                if (reader[3].ToString() == textBox2.Text)
                {
                    if (reader[3].ToString() == "Ro2Jq4o")
                    {
                        AdminMail form_adm_mail = new AdminMail(this, textBox1.Text.ToString(), reader[1].ToString());
                        form_adm_mail.Show();
                        this.Hide();
                    }
                    else
                    {
                        UserMail form_user_mail = new UserMail(this, textBox1.Text.ToString(), reader[1].ToString());
                        form_user_mail.Show();
                        this.Hide();
                    }
                    
                }
                else
                {
                    MessageBox.Show("Пароль неверный! Попробуйте еще раз");
                }
                myConnection.Close();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!((e.KeyChar >= 48 && e.KeyChar <= 57) || (e.KeyChar >= 65 && e.KeyChar <= 90) || (e.KeyChar >= 97 && e.KeyChar <= 122) || number == 8))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!((e.KeyChar >= 48 && e.KeyChar <= 57) || (e.KeyChar >= 65 && e.KeyChar <= 90) || (e.KeyChar >= 97 && e.KeyChar <= 122) || number == 8))
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            registration form_reg = new registration(this);
            form_reg.Show();
            this.Hide();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
        }

        private void autoInput()
        {
            string namePC = System.Net.Dns.GetHostName();
           
            // создаем экземпляр класса OleDbConnection
            myConnection = new OleDbConnection(connectString);

            // открываем соединение с БД
            myConnection.Open();

            string query = "SELECT * FROM [autoInput] WHERE [Имя компьютера]='" + namePC + "'";

            OleDbCommand command = new OleDbCommand(query, myConnection);

            OleDbDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    textBox1.Text = reader[1].ToString();
                    textBox2.Text = reader[2].ToString();
                    if (reader[4].ToString() == "0")
                    {
                        checkBox1.Checked = false;
                    }
                    else
                    {
                        checkBox1.Checked = true;
                    }
                }
            }
            myConnection.Close();
        }

        private bool check_namePC_AutoInput()
        {
            bool is_check = false;

            string namePC = System.Net.Dns.GetHostName();

            // создаем экземпляр класса OleDbConnection
            myConnection = new OleDbConnection(connectString);

            // открываем соединение с БД
            myConnection.Open();

            string query = "SELECT * FROM [autoInput] WHERE [Имя компьютера]='" + namePC + "'";

            OleDbCommand command = new OleDbCommand(query, myConnection);

            OleDbDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
                is_check = true;

            myConnection.Close();

            return is_check;
        }

        private void insert_namePC_AutoInput()
        {
            string namePC = System.Net.Dns.GetHostName();
            myConnection = new OleDbConnection(connectString);

            // открываем соединение с БД
            myConnection.Open();

            // текст запроса
            string query = "INSERT INTO [autoInput] (Логин,Пароль,[Имя компьютера],[Состояние чекбокса])" + "VALUES ('" + textBox1.Text.ToString() + "','" + textBox2.Text.ToString() + "','" + namePC +"','"+"1"+ "')";

            // MessageBox.Show(query);
            // создаем объект OleDbCommand для выполнения запроса к БД MS Access
            OleDbCommand command = new OleDbCommand(query, myConnection);

            // выполняем запрос к MS Access
            command.ExecuteNonQuery();

            myConnection.Close();
        }

        private void update_namePC_AutoInput()
        {
            string namePC = System.Net.Dns.GetHostName();
            myConnection = new OleDbConnection(connectString);

            myConnection.Open();

            string query = "UPDATE [autoInput] SET [Логин]='" + textBox1.Text.ToString() + "', [Пароль]='" + textBox2.Text.ToString() + "' WHERE [Имя компьютера]='" +namePC+"'";
            // создаем объект OleDbCommand для выполнения запроса к БД MS Access
            OleDbCommand command = new OleDbCommand(query, myConnection);

            // выполняем запрос к MS Access
            command.ExecuteNonQuery();

            myConnection.Close();
        }

        private void delete_namePC_AutoInput()
        {
            string namePC = System.Net.Dns.GetHostName();
            myConnection = new OleDbConnection(connectString);

            myConnection.Open();

            string query = "DELETE FROM [autoInput] WHERE [Имя компьютера]='" +namePC + "'";
            // создаем объект OleDbCommand для выполнения запроса к БД MS Access
            OleDbCommand command = new OleDbCommand(query, myConnection);

            // выполняем запрос к MS Access
            command.ExecuteNonQuery();

            myConnection.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            check_PowerOff();
        }
        private void check_PowerOff()
        {
            myConnection = new OleDbConnection(connectString);

            // открываем соединение с БД
            myConnection.Open();

            string query = "SELECT * FROM [configAdmin] WHERE [Отключение]=1";

            OleDbCommand command = new OleDbCommand(query, myConnection);

            OleDbDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                MessageBox.Show("Версия программы устарела. Требуется обновление.");
                myConnection.Close();
                this.Close();
            }
            else
            {
                myConnection.Close();
            }
        }

    }
}
