﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using System.Diagnostics;



namespace Mail
{
    public partial class SendViewForm : Form
    {
        private UserMail user_Form; //переменная для формы если вызвана с пользователя
        private AdminMail admin_Form; // переменная для формы если вызвана с администратора

        private string path_OpenFile = "";//путь для функции открыть файл
        private string path_ForSend = "";//путь для отправки насервер
        private string path_ForDownload = "";//путь для скачивания с сервера
        private string name_AdminMail_table = "upravdel304a";//логи администратора
        private string Login_Sendler = "";//логин полученный с форм с таблицами
        private string MainRegime="";//переменная для определения режима: отправка, просмотр, администратор
        private string numberNext_send = "";//номер следующего отправления
        private string path_ForAccount = "";//путьк отчету

        private DB_Data_ db_For_View = new DB_Data_();//структура для просмотра таблицы базы данных

        public static string connectStringForMail = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_MailUsers.accdb;";//для соеденнения с базой

        private OleDbConnection myConnection;//для установления соеденения с базой

        public SendViewForm(UserMail f, AdminMail f1 , string regime, string Key_Row)
        {
            InitializeComponent();
            user_Form = f;//получаем форму пользователя
            admin_Form = f1;//получаемформу администратора
            
            saveFileDialog1.Filter = "PDF files(*.pdf)|*.pdf|Архив ZIP - WinRAR files(*.zip)|*.zip";//устанавливаем фильтр для сохранения файлов
            MainRegime = regime;//устанавливаем режим

            switch (regime)//условный оператор выбора режима
            {
                case "Send"://режм отправки
                    comboBox2.SelectedIndex = 0;//устанавливаем значение "не отправлено"
                    comboBox3.SelectedIndex = 0;//устанавливаем значение "отчета нет"
                    path_ForSend = @"\\negas\Obmen\Mail\" + user_Form.getLogin() + @"\Send\";//определяем путь для отправки
                    Login_Sendler = user_Form.getLogin();//определеяем логин отправителя
                    break;
                case "View"://режим просмотра
                    Login_Sendler = user_Form.getLogin();//опред. лог. польз.
                    db_For_View = get_DB_For_View(user_Form.get_KeyRow());//получаем данные из строчки
                    path_ForSend = @"\\negas\Obmen\Mail\" + user_Form.getLogin() + @"\Send\";//путь для отправления
                    settingsViewWindow_View(db_For_View);//задаем параметры формы
                    break;
                case "Admin"://режим администратора
                    Login_Sendler = admin_Form.get_Login_Sendler();//опред. лог. польз.
                    db_For_View = get_DB_For_View(admin_Form.get_KeyRow());//получаем данные строчки из таблицы
                    settingsViewWindow_View_For_Admin(db_For_View);//задаем настройки формы
                    path_ForAccount = @"\\negas\Obmen\Mail\" + Login_Sendler + @"\Account\";//устанавливаем путь для сохранения отчета
                    break;
                case "Change":
                    Login_Sendler = user_Form.getLogin();
                    db_For_View = get_DB_For_View(user_Form.get_KeyRow());
                    path_ForSend = @"\\negas\Obmen\Mail\" + user_Form.getLogin() + @"\Send\";//путь для отправления
                    settingsViewWindow_For_User_Change(db_For_View);
                    break;
            }
        }

        //событие при закрытии
        private void SendViewForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MainRegime == "Admin")
            {
                admin_Form.upload_CheckNumber("");
                admin_Form.Show();//показываем форму админа
            }
            else
            {
                user_Form.delete_CheckNumber(user_Form.getLogin());
                user_Form.Show();//показываем форму пользователя
            }
            
        }

        //событие нажатия клавиш
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar <= 127 && number != 8 && number != 32 && number!= 45 && !(number >= 48 && number <=57) )//условие для отмены нажатия клавиш
            {
                e.Handled = true;
            }
        }

        //событие для активации окна фио если выбрано для вручения
        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if(comboBox1.SelectedItem.ToString()=="Для вручения")
            {
                textBox2.Enabled=true;
            }
            else
            {
                textBox2.Enabled = false;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar <= 127 && number != 8 && number != 32 && number != 45 && number!=46)
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            path_OpenFile = openFileDialog1.FileName;
            textBox3.Text = path_OpenFile;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (MainRegime == "Admin")
            {
                db_For_View.data_account = DateTime.Now.ToShortDateString();
                db_For_View.time_account = DateTime.Now.ToShortTimeString();

                db_For_View.status_send = comboBox2.SelectedItem.ToString();

                db_For_View.status_account = comboBox3.SelectedItem.ToString();
                db_For_View.path_to_account = sendFile(path_OpenFile, path_ForAccount, db_For_View.number_case, db_For_View.subject, db_For_View.data_account, db_For_View.time_account);
                db_For_View.other_text = textBox5.Text.ToString();

                updateToDB(db_For_View);
                updateToDB_for_Admin(db_For_View);

                admin_Form.update_DataGridView();

                MessageBox.Show("Изменения сохранены!");

                this.Close();

            }
            else
            {
                if(MainRegime=="Change"&&textBox3.Text=="Отправлен на сервер")
                {
                    MessageBox.Show("Пожалуйста, заново добавьте файл.");
                }
                else
                {
                    DB_Data_ db_data_forse = new DB_Data_();
                    db_data_forse.data = DateTime.Now.ToShortDateString();
                    db_data_forse.time = DateTime.Now.ToShortTimeString();
                    db_data_forse.number_case = textBox1.Text.ToString();
                    if (comboBox1.SelectedItem.ToString() == "Для вручения")
                    {
                        db_data_forse.subject = comboBox1.SelectedItem.ToString() +textBox2.Text.ToString();
                    }
                    else
                    {
                        db_data_forse.subject = comboBox1.SelectedItem.ToString();
                    }
                    db_data_forse.status_send = comboBox2.SelectedItem.ToString();

                    db_data_forse.status_account = comboBox3.SelectedItem.ToString();

                    db_data_forse.data_account = "";
                    db_data_forse.time_account = "";

                    db_data_forse.path_to_send = sendFile(path_OpenFile, path_ForSend, db_data_forse.number_case, db_data_forse.subject, db_data_forse.data, db_data_forse.time);
                    db_data_forse.path_to_account = "";
                    db_data_forse.other_text = textBox5.Text.ToString();

                    if (MainRegime == "Change")
                    {
                        change_updateToDB(db_data_forse);
                        change_updateToDB_for_Admin(db_data_forse);
                        MessageBox.Show("Отправление изменено!");
                    }
                    else
                    {
                        insertToDB(db_data_forse);

                        numberNext_send = GetLastNumberSend().ToString();
                        insertToDb_for_Admin(db_data_forse);
                        MessageBox.Show("Отправление создано!");
                    }
                    user_Form.UpdateDataGridView();
                    this.Close();
                }
            }
        }

        private int GetLastNumberSend()
        {
            myConnection = new OleDbConnection(connectStringForMail);

            // открываем соединение с БД
            myConnection.Open();

            DataTable dtE = new DataTable();

            string query = "SELECT MAX(Код) FROM " + user_Form.getLogin();

            // создаем объект OleDbCommand для выполнения запроса к БД MS Access
            OleDbCommand command = new OleDbCommand(query, myConnection);

            int max = (int)command.ExecuteScalar();
            myConnection.Close();

            return max;
        }

        private void insertToDB(DB_Data_ db)
        {
            myConnection = new OleDbConnection(connectStringForMail);

            myConnection.Open();

            string query = "INSERT INTO [" + user_Form.getLogin() + "] (Дата,Время,[№ дела],Тема,[Статус отправки],[Статус отчета],[Дата отчета],[Время отчета],[Путь к файлу],[Путь к отчету],Примечание)" + "VALUES ('" + db.data + "','" + db.time + "','" + db.number_case + "','" + db.subject + "','" + db.status_send + "','" + db.status_account + "','" + db.data_account + "','" + db.time_account + "','" + db.path_to_send + "','" + db.path_to_account + "','" + db.other_text + "')";


            OleDbCommand command = new OleDbCommand(query, myConnection);

            command.ExecuteNonQuery();


            myConnection.Close();
        }

        private void insertToDb_for_Admin(DB_Data_ db)
        {
            myConnection = new OleDbConnection(connectStringForMail);

            myConnection.Open();

            string query = "INSERT INTO [" + name_AdminMail_table + "] (Исполнитель,ФИО,Дата,Время,Примечание,[Код отправления],[Статус отправки],[Статус отчета])" + "VALUES ('" + user_Form.getLogin() + "','"+user_Form.get_NameUser()+"','"+ db.data + "','" + db.time + "','" + db.other_text + "','" + numberNext_send +"','"+db.status_send+"','"+db.status_account+"')";

            OleDbCommand command = new OleDbCommand(query, myConnection);

            command.ExecuteNonQuery();


            myConnection.Close();
        }

        private void change_updateToDB(DB_Data_ db)
        {
            myConnection = new OleDbConnection(connectStringForMail);

            myConnection.Open();

            string query = "UPDATE [" + Login_Sendler + "] SET [Дата]='"+db.data+"', [Время]='"+db.time+"', [№ дела]='"+db.number_case+"', [Тема]='"+db.subject+"', [Статус отправки]='"+db.status_send+"', [Статус отчета]='"+db.status_account+"', [Дата отчета]='"+db.data_account+"', [Время отчета]='"+db.time_account+"', [Путь к файлу]='"+db.path_to_send+"', [Путь к отчету]='"+db.path_to_account+"', [Примечание]='"+db.other_text+"' WHERE [Код]=" + user_Form.get_KeyRow();
            // создаем объект OleDbCommand для выполнения запроса к БД MS Access
            OleDbCommand command = new OleDbCommand(query, myConnection);

            // выполняем запрос к MS Access
            command.ExecuteNonQuery();

            myConnection.Close();
        }

        private void change_updateToDB_for_Admin(DB_Data_ db)
        {
            myConnection = new OleDbConnection(connectStringForMail);

            myConnection.Open();

            string query = "UPDATE [" + name_AdminMail_table + "] SET [Исполнитель]='"+user_Form.getLogin()+"', [Дата]='" + db.data + "', [Время]='" + db.time + "', [Примечание]='" + db.other_text + "', [Статус отправки]='" + db.status_send + "', [Статус отчета]='" + db.status_account + "' WHERE [Код отправления]='" + user_Form.get_KeyRow()+"'";

            OleDbCommand command = new OleDbCommand(query, myConnection);

            command.ExecuteNonQuery();


            myConnection.Close();
        }

        private void updateToDB(DB_Data_ db)
        {
            myConnection = new OleDbConnection(connectStringForMail);

            myConnection.Open();

            string query = "UPDATE [" + Login_Sendler + "] SET [Статус отправки]='" + db.status_send + "', [Статус отчета]='" + db.status_account + "',[Дата отчета]='" + db.data_account + "',[Время отчета]='" + db.time_account + "',[Путь к отчету]='" + db.path_to_account + "', [Примечание]='" + db.other_text + "' WHERE [Код]=" + admin_Form.get_KeyRow();
            // создаем объект OleDbCommand для выполнения запроса к БД MS Access
            OleDbCommand command = new OleDbCommand(query, myConnection);

            // выполняем запрос к MS Access
            command.ExecuteNonQuery();

            myConnection.Close();
        }

        private void updateToDB_for_Admin(DB_Data_ db)
        {
            myConnection = new OleDbConnection(connectStringForMail);

            myConnection.Open();

            string query = "UPDATE [" + name_AdminMail_table + "] SET [Статус отправки]='" + db.status_send + "', [Статус отчета]='" + db.status_account + "',[Примечание]='" + db.other_text + "' WHERE [Код]=" + admin_Form.get_KeyRowAdmin();
            // создаем объект OleDbCommand для выполнения запроса к БД MS Access
            OleDbCommand command = new OleDbCommand(query, myConnection);

            // выполняем запрос к MS Access
            command.ExecuteNonQuery();

            myConnection.Close();
        }

        private string sendFile(string oldPath, string newPath, string nameFile, string themeFile, string data, string time)
        {
            string extencion = Path.GetExtension(oldPath);
            data = data.Replace(".", "-");
            time = time.Replace(":", "-");
            newPath = newPath + data + "-" + time + "-" + nameFile + "-" + themeFile+extencion;
            FileInfo fileInf = new FileInfo(oldPath);
            if (fileInf.Exists)
            {
                fileInf.CopyTo(newPath, true);
                return newPath;
            }else
            {
                MessageBox.Show("Файла не существует.");
                return "";
            }
        }

        private DB_Data_ get_DB_For_View(string key_Row )
        {
            DB_Data_ db = new DB_Data_();

            myConnection = new OleDbConnection(connectStringForMail);

            myConnection.Open();


           string query = "SELECT * FROM [" + Login_Sendler + "] WHERE [Код]=" + key_Row;

            OleDbCommand command = new OleDbCommand(query, myConnection);

            OleDbDataReader reader = command.ExecuteReader();

            

            while (reader.Read())
            {
                db.data = reader[1].ToString();
                db.time = reader[2].ToString();
                db.number_case = reader[3].ToString();
                db.subject = reader[4].ToString(); // переделать
                db.status_send = reader[5].ToString();
                db.status_account = reader[6].ToString();
                db.data_account = reader[7].ToString();
                db.time_account = reader[8].ToString();
                db.path_to_send = reader[9].ToString();
                db.path_to_account = reader[10].ToString();
                db.other_text = reader[11].ToString();
            }
            reader.Close();


            return db;
        }


        private void settingsViewWindow_View(DB_Data_ db)
        {
            //номер дела
            textBox1.Enabled = false;
            textBox1.Text = db.number_case;

            //тема
            comboBox1.Enabled = false;
            textBox2.Enabled = false;

            if(db.subject.StartsWith("Для вручения"))
            {
                string theme = "";
                string fio = "";
                string[] words = db.subject.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string s in words)
                {
                    if (s == "Для" || s == "вручения")
                        theme = theme + s + " ";
                    else
                        fio = fio + s + " ";
                }
                comboBox1.Text = theme;
                textBox2.Text = fio;
            }
            else
            {
                comboBox1.Text = db.subject;
            }

            //файл
            textBox3.Enabled = false;
            textBox3.Text = "Отправлен на сервер";

            //кнопка добавить файл на отправку
            button1.Enabled = false;
            //кнопка скачать
            button2.Enabled = true;
            //Отчет
            textBox4.Enabled = false;
            if (db.status_account== "Отчета нет")
            {
                button4.Enabled = false;
                comboBox3.SelectedIndex = 0;
            }
            else
            {
                button4.Enabled = true;
                textBox4.Text = "Загружен на сервер";
                comboBox3.Text = db.status_account;
            }
            //кнопка добавить отчет
            button3.Enabled = false;
            //статус отправки
            comboBox2.Enabled = false;
            comboBox2.Text = db.status_send;
            //статус отчета
            comboBox3.Enabled = false;
            comboBox3.Text = db.status_account;
            //примечание
            textBox5.Text = db.other_text;
            textBox5.Enabled = false;
            //создать;
            button5.Enabled = false;
        }

        private void settingsViewWindow_For_User_Change(DB_Data_ db)
        {
            //номер дела
            textBox1.Enabled = true;
            textBox1.Text = db.number_case;

            comboBox1.Enabled = true;

            if (db.subject.StartsWith("Для вручения"))
            {
                string theme = "";
                string fio = "";
                string[] words = db.subject.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string s in words)
                {
                    if (s == "Для" || s == "вручения")
                        theme = theme + s + " ";
                    else
                        fio = fio + s + " ";
                }
                comboBox1.SelectedItem = theme;
                textBox2.Text = fio;
            }
            else
            {
                comboBox1.SelectedItem = db.subject;
            }
            //файл
            textBox3.Enabled = false;
            textBox3.Text = "Отправлен на сервер";

            //кнопка добавить файл на отправку
            button1.Enabled = true;
            //кнопка скачать
            button2.Enabled = true;
            //Отчет
            textBox4.Enabled = false;
            if (db.status_account == "Отчета нет")
            {
                button4.Enabled = false;
                comboBox3.SelectedIndex = 0;
            }
            else
            {
                button4.Enabled = true;
                textBox4.Text = "Загружен на сервер";
                comboBox3.Text = db.status_account;
            }
            //кнопка добавить отчет
            button3.Enabled = false;
            //статус отправки
            comboBox2.Enabled = false;
            comboBox2.Text = db.status_send;
            //статус отчета
            comboBox3.Enabled = false;
            comboBox3.Text = db.status_account;
            //примечание
            textBox5.Text = db.other_text;
            textBox5.Enabled = true;
            //создать;
            button5.Text = "Изменить";
            button5.Enabled = true;

        }

        private void settingsViewWindow_View_For_Admin(DB_Data_ db)
        {
            //номер дела
            textBox1.Enabled = false;
            textBox1.Text = db.number_case;

            //тема
            comboBox1.Enabled = false;
            textBox2.Enabled = false;

            if (db.subject.StartsWith("Для вручения"))
            {
                string theme = "";
                string fio = "";
                string[] words = db.subject.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string s in words)
                {
                    if (s == "Для" || s == "вручения")
                        theme = theme + s + " ";
                    else
                        fio = fio + s + " ";
                }
                comboBox1.Text = theme;
                textBox2.Text = fio;
            }
            else
            {
                comboBox1.Text = db.subject;
            }

            //файл
            textBox3.Enabled = false;
            textBox3.Text = "Отправлен на сервер";

            //кнопка добавить файл на отправку
            button1.Enabled = false;
            //кнопка скачать
            button2.Enabled = true;
            //Отчет
            textBox4.Enabled = false;
            if (db.status_account == "Отчета нет")
            {
                button4.Enabled = false;
                comboBox3.SelectedIndex = 0;
            }
            else
            {
                button4.Enabled = true;
                textBox4.Text = "Загружен на сервер";
                comboBox3.Text = db.status_account;
            }
            //кнопка добавить отчет
            button3.Enabled = true;
            //статус отправки
            comboBox2.Enabled = true;
            //статус отчета
            comboBox3.Enabled = true;
            //примечание
            textBox5.Text = db.other_text;
            textBox5.Enabled = true;
            //создать
            button5.Text = "Сохранить";
            button5.Enabled = true;
        }

        struct DB_Data_
        {
            public string data;
            public string time;
            public string number_case;
            public string subject;
            public string status_send;
            public string status_account;
            public string data_account;
            public string time_account;
            public string path_to_send;
            public string path_to_account;
            public string other_text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string extencion = Path.GetExtension(db_For_View.path_to_send);
            if (extencion == ".pdf")
                saveFileDialog1.FilterIndex = 1;
            else
                saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.FileName = db_For_View.number_case + " "+db_For_View.subject;
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            path_ForDownload = saveFileDialog1.FileName;
            string path = db_For_View.path_to_send;
            string newPath = path_ForDownload;
            FileInfo fileInf = new FileInfo(path);
            if (fileInf.Exists)
            {
                fileInf.CopyTo(newPath, true);
                Process.Start(newPath);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string extencion = Path.GetExtension(db_For_View.path_to_account);
            if (extencion == ".pdf")
                saveFileDialog1.FilterIndex = 1;
            else
                saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.FileName = db_For_View.number_case + " Отчёт";
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            // получаем выбранный файл
            path_ForDownload = saveFileDialog1.FileName;
            string path = db_For_View.path_to_account;
            string newPath = path_ForDownload;
            FileInfo fileInf = new FileInfo(path);
            if (fileInf.Exists)
            {
                fileInf.CopyTo(newPath, true); 
                Process.Start(newPath);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            path_OpenFile = openFileDialog1.FileName;
            textBox4.Text = path_OpenFile;
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 0)
                e.Handled = true;
        }
    }
}
