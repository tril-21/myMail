﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;

namespace Mail
{
    public partial class UserMail : Form
    {
        private Form1 form_auto;
        private string Login = "";
        private string NameUser = "";
        private string KEY_row = "";

        private string query_Update = ""; 

        public static string connectString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_Users.accdb;";
        public static string connectStringForMail = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_MailUsers.accdb;";

        // поле - ссылка на экземпляр класса OleDbConnection для соединения с БД
        private OleDbConnection myConnection;
        public UserMail(Form1 f, string login, string name)
        {
            InitializeComponent();
            form_auto = f;

            Login = login;
            NameUser = name;
            query_Update = "SELECT [Код], [Дата], [Время], [№ дела], [Тема], [Статус отправки], [Статус отчета] FROM " + Login;

        dataGridView1.DataSource = GetEmployeesList();
            label1.Text = "Пользователь: " + NameUser;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index_Row=e.RowIndex;
            if (index_Row < 0)
            {

            }
            else
            {
                KEY_row = dataGridView1.Rows[index_Row].Cells[0].Value.ToString();
                if (dataGridView1.Rows[index_Row].Cells[5].Value.ToString() == "Не отправлено")
                {
                    button4.Enabled = true;
                }
                else
                {
                    button4.Enabled = false;
                }
            }
            
        }

        private void UserMail_FormClosing(object sender, FormClosingEventArgs e)
        {
            form_auto.Close();
        }

        private DataTable GetEmployeesList()
        {
            myConnection = new OleDbConnection(connectStringForMail);

            // открываем соединение с БД
            myConnection.Open();

            DataTable dtE = new DataTable();

            string query = query_Update;

            // создаем объект OleDbCommand для выполнения запроса к БД MS Access
            OleDbCommand command = new OleDbCommand(query, myConnection);

            OleDbDataReader reader = command.ExecuteReader();


            dtE.Load(reader);

            myConnection.Close();

            return dtE;
        }

        private void settings_DataGrid()
        {
            dataGridView1.AutoResizeColumns();
            DataGridViewCellStyle style = dataGridView1.ColumnHeadersDefaultCellStyle;
            style.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SendViewForm sendV_Form = new SendViewForm(this,null ,"Send", KEY_row);
            sendV_Form.Show();
            this.Hide();
        }

        public string getLogin()
        {
            return Login;
        }

        public void UpdateDataGridView()
        {
            dataGridView1.DataSource = GetEmployeesList();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = GetEmployeesList();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (KEY_row != ""&&check_upload_CheckNumber())
            {
                upload_CheckNumber(getLogin());
                SendViewForm semdV_Form = new SendViewForm(this,null, "View", KEY_row);
                semdV_Form.Show();
                this.Hide();
            } else
            {
                MessageBox.Show("Укажите, нажав левой кнопкой мыши, в таблице нужное Вам отправление.");
            }
            
        }
        
        public string get_KeyRow()
        {
            return KEY_row;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index_Row = e.RowIndex;
            if (index_Row < 0)
            {

            }
            else
            {
                KEY_row = dataGridView1.Rows[index_Row].Cells[0].Value.ToString();
                if(dataGridView1.Rows[index_Row].Cells[5].Value.ToString()=="Не отправлено")
                {
                    button4.Enabled = true;
                }
                else
                {
                    button4.Enabled = false;
                }
            }
        }

        private void dataGridView1_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            DataGridView grid = sender as DataGridView;

            if (grid != null)
            {
                if (dataGridView1[5, e.RowIndex].Value.ToString() == "Не отправлено")
                    grid.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Red;
                else if((dataGridView1[5, e.RowIndex].Value.ToString() == "Отправлено"&& dataGridView1[6, e.RowIndex].Value.ToString()== "Есть не все") || dataGridView1[5, e.RowIndex].Value.ToString()=="Есть ошибки")
                    grid.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Yellow;
                else if(dataGridView1[5, e.RowIndex].Value.ToString() == "Отправлено" && dataGridView1[6, e.RowIndex].Value.ToString() == "Есть")
                    grid.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Green;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (KEY_row != ""&&check_upload_CheckNumber())
            {
                upload_CheckNumber(getLogin());
                SendViewForm semdV_Form = new SendViewForm(this, null, "Change", KEY_row);
                semdV_Form.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Укажите, нажав левой кнопкой мыши, в таблице нужное Вам отправление.");
            }
        }

        private bool check_upload_CheckNumber()
        {
            bool is_free = true;
            myConnection = new OleDbConnection(connectStringForMail);//устанавливаем соединение
            myConnection.Open();//откраваем соединение

            string query = "SELECT * FROM [check_user]";//запрос на выборку

            OleDbCommand command = new OleDbCommand(query, myConnection);//создаем команду
            OleDbDataReader reader = command.ExecuteReader();//выполняем команду

            while (reader.Read())
            {
                if (reader[1].ToString() == Login)
                {
                    is_free = false;
                    break;
                }

            }
            myConnection.Close();//закрывает соединение

            return is_free;
        }
        public void upload_CheckNumber(string log_st)
        {
            myConnection = new OleDbConnection(connectStringForMail);//устанавливаем соединение
            myConnection.Open();//откраваем соединение

            string query = "INSERT INTO [check_admin] ([Исполнитель]) VALUES ('" + log_st + "')";

            OleDbCommand command = new OleDbCommand(query, myConnection);

            command.ExecuteNonQuery();

            myConnection.Close();//закрывает соединение*/
        }
        public void delete_CheckNumber(string log_st)
        {
            myConnection = new OleDbConnection(connectStringForMail);//устанавливаем соединение
            myConnection.Open();//откраваем соединение
            string query = "DELETE FROM [check_admin] WHERE [Исполнитель]='"+log_st+"'";
            // создаем объект OleDbCommand для выполнения запроса к БД MS Access
            OleDbCommand command = new OleDbCommand(query, myConnection);

            // выполняем запрос к MS Access
            command.ExecuteNonQuery();
            myConnection.Close();
        }
        public string get_NameUser()
        {
            return NameUser;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Filter_Form filter = new Filter_Form(null, this, "User", Login);
            this.Hide();
            filter.Show();
        }

        public void change_queryUpdate(string query)
        {
            query_Update = query;
        }
    }
}
