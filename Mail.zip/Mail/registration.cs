﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;

namespace Mail
{
    public partial class registration : Form
    {
        private Form1 form_auto;

        // строка подключения к MS Access
        // вариант 1
        // public static string connectString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=ListM.mdb;";
        // вариант 2
        public static string connectString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_Users.accdb;";
        public static string connectStringForMail = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_MailUsers.accdb;";

        // поле - ссылка на экземпляр класса OleDbConnection для соединения с БД
        private OleDbConnection myConnection;


        public registration(Form1 f)
        {
            InitializeComponent();
            form_auto = f;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar <= 127 && number != 8 && number != 32)
            {
                e.Handled = true;
            }
        }

        private void registration_FormClosing(object sender, FormClosingEventArgs e)
        {
            form_auto.Show();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!((e.KeyChar >= 48 && e.KeyChar <= 57) || (e.KeyChar >= 65 && e.KeyChar <= 90) || (e.KeyChar >= 97 && e.KeyChar <= 122) || number == 8))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!((e.KeyChar >= 48 && e.KeyChar <= 57) || (e.KeyChar >= 65 && e.KeyChar <= 90) || (e.KeyChar >= 97 && e.KeyChar <= 122) || number == 8))
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 4||textBox1.TextLength>18)
            {
                MessageBox.Show("Ошибка! Длина логина должна быть от 4 до 18 символов.");
            } else if (textBox2.TextLength < 4 || textBox2.TextLength > 18)
            {
                MessageBox.Show("Ошибка! Длина пароля должна быть от 4 до 18 символов.");
            } else if (textBox3.TextLength == 0)
            {
                MessageBox.Show("Ошибка! Заполните пожалуйста поле \"Фамилия и инициалы\".");
            } else
            {
                if (checkIsValidData(textBox1.Text.ToString()))
                {
                    myConnection = new OleDbConnection(connectString);

                    // открываем соединение с БД
                    myConnection.Open();

                    // текст запроса
                    string query = "INSERT INTO [users] (ФИО,Логин,Пароль)" + "VALUES ('" + textBox3.Text.ToString() + "','" + textBox1.Text.ToString() + "','" + textBox2.Text.ToString() + "')";

                    // MessageBox.Show(query);
                    // создаем объект OleDbCommand для выполнения запроса к БД MS Access
                    OleDbCommand command = new OleDbCommand(query, myConnection);

                    // выполняем запрос к MS Access
                    command.ExecuteNonQuery();

                    create_Dir_For_User_in_Mail(textBox1.Text.ToString());
                    create_Table_For_Mail(textBox1.Text.ToString());

                    //  CreateAndSort();
                    textBox3.Text = "";
                    textBox1.Text = "";
                    textBox2.Text = "";

                    myConnection.Close();

                    MessageBox.Show("Пользователь зарегистрирован!");
                    this.Close();
                }
            }
        }

        private bool checkIsValidData(string login)
        {
            bool v=true;

            myConnection = new OleDbConnection(connectString);

            myConnection.Open();

            string query = "SELECT * FROM [users] WHERE [Логин]='" + textBox1.Text.ToString() + "'";

            OleDbCommand command = new OleDbCommand(query, myConnection);

            OleDbDataReader reader = command.ExecuteReader();

            if (reader.HasRows == false)
            {
                v = true;
                myConnection.Close();
            }
            else
            {
                v = false;
                MessageBox.Show("Данный логин занят. Введите заново.");
                textBox1.Text="";
                textBox2.Text = "";
                myConnection.Close();
            }
            return v; 
        }

        private void create_Dir_For_User_in_Mail(string login)
        {
            string path = @"\\negas\Obmen\Mail\" +login;
            string subpath = @"Send";
            string subpath2 = @"Account";
            DirectoryInfo dirInfo = new DirectoryInfo(path);
            if (!dirInfo.Exists)
            {
                dirInfo.Create();
            }
            dirInfo.CreateSubdirectory(subpath);
            dirInfo.CreateSubdirectory(subpath2);
        }

        private void create_Table_For_Mail(string login)
        {
            myConnection = new OleDbConnection(connectStringForMail);
            myConnection.Open();
            string strTemp = "[Код] AUTOINCREMENT PRIMARY KEY, [Дата] text, [Время] text, [№ дела] text, [Тема] text, [Статус отправки] text, [Статус отчета] text, [Дата отчета] text, [Время отчета] text, [Путь к файлу] text, [Путь к отчету] text, [Примечание] text ";
            OleDbCommand myCommand = new OleDbCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "CREATE TABLE "+login+"(" + strTemp + ")";
            myCommand.ExecuteNonQuery();
            myCommand.Connection.Close();
            myConnection.Close();
        }
    }
}